
## Rocky linux docker configuration

```shell
dnf -y install epel-release --> jeśli to jest rocky linux 
dnf -y update
dnf -y install yum-utils rsync unzip htop mc wget screen nano
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
dnf -y install docker-ce docker-ce-cli containerd.io
systemctl enable --now docker
docker login docker.kambu.pl  resqmed:toeZ2ohj7i
curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
```


## Certificate SSL generation
https://linuxize.com/post/creating-a-self-signed-ssl-certificate/

## Clone git repository to local machine or dopy docker-compose configuration folder form git repository

```shell
git ssh://git@git.stash.kambu.pl:7999/rpdo/ohif-compose.git
```

## Change relevant values in java services (*.yml) and java script (ohif-viewer-config.js). 

## Run compose
```shell
docker-compose up -d
```
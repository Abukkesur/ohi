#!/bin/bash

# shellcheck disable=SC2086
docker-compose -f docker-compose.yml $1 $2